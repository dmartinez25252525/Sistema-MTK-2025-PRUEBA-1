// backend/routes/auth.js
import { Router } from "express";
import jwt from "jsonwebtoken";
import { pool } from "../db.js";

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || "super_secreto_mtk";

/** Construye el objeto de usuario para el frontend (mtk_user) */
async function buildUserPayload(idUsuarios) {
  const [[row]] = await pool.query(
    `SELECT 
       u.idUsuarios, u.email, u.nickname, COALESCE(u.Activo,1) AS UserActivo,
       p.idPersonas, p.Sedes_idSedes, s.Nombre AS SedeNombre, s.Municipio,
       pr.Roles_idRoles, r.Tipo_usuario
     FROM Usuarios u
     JOIN Personas p           ON p.idPersonas = u.Personas_idPersonas
     JOIN Personas_Roles pr    ON pr.Personas_idPersonas = p.idPersonas
     JOIN Roles r              ON r.idRoles = pr.Roles_idRoles
     LEFT JOIN Sedes s         ON s.idSedes = p.Sedes_idSedes
     WHERE u.idUsuarios=? LIMIT 1`, [idUsuarios]
  );
  if (!row || Number(row.UserActivo)!==1) return null;

  return {
    idUsuarios: row.idUsuarios,
    email: row.email,
    nickname: row.nickname,
    rolId: row.Roles_idRoles,
    rol: row.Tipo_usuario,
    idPersonas: row.idPersonas,
    idSedes: row.Sedes_idSedes,
    sede: row.SedeNombre || null,
    municipio: row.Municipio || null
  };
}

/** POST /api/auth/login  body: { email, pasword } */
router.post("/login", async (req, res) => {
  try {
    const { email, pasword } = req.body || {};
    if (!email || !pasword) return res.status(400).json({ ok:false, msg:"Email y contraseña requeridos" });

    const [[u]] = await pool.query(`SELECT idUsuarios, pasword FROM Usuarios WHERE email=? LIMIT 1`, [email]);
    if (!u) return res.status(401).json({ ok:false, msg:"Credenciales inválidas" });

    // Nota: Por compatibilidad con tu BD actual, comparamos texto plano
    if (String(u.pasword) !== String(pasword)) {
      return res.status(401).json({ ok:false, msg:"Credenciales inválidas" });
    }

    const token = jwt.sign({ idUsuarios: u.idUsuarios }, JWT_SECRET, { expiresIn: "8h" });
    const user = await buildUserPayload(u.idUsuarios);
    if (!user) return res.status(401).json({ ok:false, msg:"Usuario inactivo/no encontrado" });

    res.json({ ok:true, token, user });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok:false, msg:"Error en login" });
  }
});

export default router;
