// backend/routes/alumnos.js
import { Router } from "express";
import { pool } from "../db.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

// ---- catálogos ----
router.get("/catalogos", requireAuth, async (_req, res) => {
  try {
    const [generos]  = await pool.query(`SELECT idGeneros, Descripcion FROM Generos ORDER BY Descripcion`);
    const [sedes]    = await pool.query(`SELECT idSedes, Nombre, Municipio FROM Sedes ORDER BY Nombre`);
    const [programa] = await pool.query(`SELECT idPrograma, Descripcion FROM Programa ORDER BY Descripcion`);
    const [cintas]   = await pool.query(`SELECT idCinta, Color, Programa_idPrograma FROM Cinta ORDER BY Color`);
    res.json({ ok:true, data:{ generos, sedes, programas: programa, cintas } });
  } catch (e) { console.error(e); res.status(500).json({ ok:false, msg:"Error catálogos" }); }
});

// ---- listado con filtros ----
router.get("/", requireAuth, async (req, res) => {
  try {
    const { rol, sedesPermitidas } = req.user;

    const q           = String(req.query.q || "").trim();
    const sedeId      = Number(req.query.sedeId || 0);
    const programaId  = Number(req.query.programaId || 0);
    const cintaId     = Number(req.query.cintaId || 0);
    const edadMin     = Number(req.query.edadMin || 0);
    const edadMax     = Number(req.query.edadMax || 0);

    const where = [];
    const args  = [];

    if (!["Administrador","Secretaria"].includes(rol)) {
      if (Array.isArray(sedesPermitidas) && sedesPermitidas.length) {
        where.push(`p.Sedes_idSedes IN (${sedesPermitidas.map(s=>Number(s.idSedes)).join(",")})`);
      }
    }
    if (q) {
      where.push(`(p.Primer_nombre LIKE ? OR p.Primer_apellido LIKE ? OR p.Segundo_apellido LIKE ?)`);
      args.push(`%${q}%`, `%${q}%`, `%${q}%`);
    }
    if (sedeId)     { where.push(`p.Sedes_idSedes = ?`); args.push(sedeId); }
    if (programaId) { where.push(`c.Programa_idPrograma = ?`); args.push(programaId); }
    if (cintaId)    { where.push(`c.idCinta = ?`); args.push(cintaId); }
    if (edadMin)    { where.push(`p.Edad >= ?`); args.push(edadMin); }
    if (edadMax)    { where.push(`p.Edad <= ?`); args.push(edadMax); }

    const [rows] = await pool.query(
      `
      SELECT 
        p.idPersonas, p.Primer_nombre, p.Segundo_nombre, p.Primer_apellido, p.Segundo_apellido,
        p.Telefono, p.Persona_emergencia, p.Contacto_emergencia, p.Edad,
        p.Fecha_nac, p.Año_inicio, p.Sedes_idSedes, p.Generos_idGeneros,
        s.Nombre AS Sede, g.Descripcion AS Genero,
        c.idCinta, c.Color AS CintaColor, pg.Descripcion AS Programa
      FROM Personas p
      LEFT JOIN Sedes s    ON s.idSedes = p.Sedes_idSedes
      LEFT JOIN Generos g  ON g.idGeneros = p.Generos_idGeneros
      LEFT JOIN Cinta_Personas cp ON cp.Personas_idPersonas = p.idPersonas
      LEFT JOIN Cinta c     ON c.idCinta = cp.Cinta_idCinta
      LEFT JOIN Programa pg ON pg.idPrograma = c.Programa_idPrograma
      ${where.length ? `WHERE ${where.join(" AND ")}` : ""}
      ORDER BY s.Nombre, p.Primer_apellido, p.Primer_nombre
      LIMIT 1000
      `,
      args
    );

    res.json({ ok:true, data: rows });
  } catch (e) { console.error(e); res.status(500).json({ ok:false, msg:"Error listando alumnos" }); }
});

// ---- detalle ----
router.get("/:id", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [[p]] = await pool.query(
      `SELECT p.*, s.Nombre AS Sede, g.Descripcion AS Genero
       FROM Personas p
       LEFT JOIN Sedes s   ON s.idSedes = p.Sedes_idSedes
       LEFT JOIN Generos g ON g.idGeneros = p.Generos_idGeneros
       WHERE p.idPersonas=? LIMIT 1`, [id]
    );
    if (!p) return res.status(404).json({ ok:false, msg:"Alumno no encontrado" });

    const [[belt]] = await pool.query(
      `SELECT cp.Cinta_idCinta AS idCinta, c.Color, c.Programa_idPrograma, pg.Descripcion AS Programa
       FROM Cinta_Personas cp
       JOIN Cinta c     ON c.idCinta = cp.Cinta_idCinta
       JOIN Programa pg ON pg.idPrograma = c.Programa_idPrograma
       WHERE cp.Personas_idPersonas=?
       ORDER BY cp.Id_Cinta_Personascol DESC
       LIMIT 1`,
      [id]
    );

    res.json({ ok:true, data:{ persona: p, cinta: belt || null } });
  } catch (e) { console.error(e); res.status(500).json({ ok:false, msg:"Error obteniendo detalle" }); }
});

// ---- crear ----
router.post("/", requireAuth, async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const persona = req.body?.persona || req.body;
    if (!persona) return res.status(400).json({ ok:false, msg:"Faltan datos de Persona" });
    const oblig = ["Primer_nombre","Primer_apellido","Sedes_idSedes","Generos_idGeneros"];
    for (const c of oblig) if (!persona[c]) return res.status(400).json({ ok:false, msg:`Falta ${c}` });

    // Sensei no puede crear/mover fuera de sus sedes
    if (!["Administrador","Secretaria"].includes(req.user.rol)) {
      const allowed = (req.user.sedesPermitidas||[]).some(s=> Number(s.idSedes)===Number(persona.Sedes_idSedes));
      if (!allowed) return res.status(403).json({ ok:false, msg:"No puedes crear alumnos en esa sede" });
    }

    await conn.beginTransaction();
    const [pIns] = await conn.query(
      `INSERT INTO Personas (
        Primer_nombre, Segundo_nombre, Primer_apellido, Segundo_apellido, Telefono,
        Persona_emergencia, Contacto_emergencia, Edad, Fecha_nac, Año_inicio,
        Sedes_idSedes, Generos_idGeneros, Ropa_personas_idRopa_personas
      ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        persona.Primer_nombre ?? null,
        persona.Segundo_nombre ?? "",
        persona.Primer_apellido ?? null,
        persona.Segundo_apellido ?? "",
        persona.Telefono ?? "",
        persona.Persona_emergencia ?? "",
        persona.Contacto_emergencia ?? "",
        persona.Edad ?? 0,
        persona.Fecha_nac ?? "2000-01-01",
        persona.Año_inicio ?? new Date().getFullYear(),
        persona.Sedes_idSedes,
        persona.Generos_idGeneros,
        persona.Ropa_personas_idRopa_personas ?? 1
      ]
    );
    await conn.commit();
    res.json({ ok:true, msg:"Alumno creado", idPersonas: pIns.insertId });
  } catch (e) {
    await conn.rollback(); console.error(e); res.status(500).json({ ok:false, msg:"Error creando alumno" });
  } finally { conn.release(); }
});

// ---- actualizar ----
router.put("/:id", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { persona } = req.body || {};
    if (!id || !persona) return res.status(400).json({ ok:false, msg:"Datos inválidos" });

    if (!["Administrador","Secretaria"].includes(req.user.rol) && persona.Sedes_idSedes) {
      const allowed = (req.user.sedesPermitidas||[]).some(s=> Number(s.idSedes)===Number(persona.Sedes_idSedes));
      if (!allowed) return res.status(403).json({ ok:false, msg:"No puedes mover alumnos a esa sede" });
    }

    await pool.query(
      `UPDATE Personas SET
         Primer_nombre = COALESCE(?, Primer_nombre),
         Segundo_nombre = COALESCE(?, Segundo_nombre),
         Primer_apellido = COALESCE(?, Primer_apellido),
         Segundo_apellido = COALESCE(?, Segundo_apellido),
         Telefono = COALESCE(?, Telefono),
         Persona_emergencia = COALESCE(?, Persona_emergencia),
         Contacto_emergencia = COALESCE(?, Contacto_emergencia),
         Edad = COALESCE(?, Edad),
         Fecha_nac = COALESCE(?, Fecha_nac),
         Año_inicio = COALESCE(?, Año_inicio),
         Sedes_idSedes = COALESCE(?, Sedes_idSedes),
         Generos_idGeneros = COALESCE(?, Generos_idGeneros)
       WHERE idPersonas=?`,
      [
        persona.Primer_nombre ?? null,
        persona.Segundo_nombre ?? null,
        persona.Primer_apellido ?? null,
        persona.Segundo_apellido ?? null,
        persona.Telefono ?? null,
        persona.Persona_emergencia ?? null,
        persona.Contacto_emergencia ?? null,
        persona.Edad ?? null,
        persona.Fecha_nac ?? null,
        persona.Año_inicio ?? null,
        persona.Sedes_idSedes ?? null,
        persona.Generos_idGeneros ?? null,
        id
      ]
    );

    res.json({ ok:true, msg:"Alumno actualizado" });
  } catch (e) { console.error(e); res.status(500).json({ ok:false, msg:"Error actualizando alumno" }); }
});

// ---- asignar/actualizar cinta (histórico) ----
router.put("/:id/cinta", requireAuth, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const cintaId = Number(req.body.cintaId);
    if (!id || !cintaId) return res.status(400).json({ ok:false, msg:"Datos inválidos" });

    await pool.query(`INSERT INTO Cinta_Personas (Cinta_idCinta, Personas_idPersonas) VALUES (?,?)`, [cintaId, id]);
    res.json({ ok:true, msg:"Cinta actualizada" });
  } catch (e) { console.error(e); res.status(500).json({ ok:false, msg:"Error actualizando cinta" }); }
});

export default router;
