// backend/middleware/auth.js
import jwt from "jsonwebtoken";
import { pool } from "../db.js";

const JWT_SECRET = process.env.JWT_SECRET || "super_secreto_mtk";

async function fetchUserProfile(idUsuarios) {
  const [rows] = await pool.query(
    `SELECT 
       u.idUsuarios, u.email, u.nickname, COALESCE(u.Activo,1) AS UserActivo,
       p.idPersonas, p.Sedes_idSedes, s.Nombre AS SedeNombre, s.Municipio,
       pr.Roles_idRoles, r.Tipo_usuario
     FROM Usuarios u
     JOIN Personas p           ON p.idPersonas = u.Personas_idPersonas
     JOIN Personas_Roles pr    ON pr.Personas_idPersonas = p.idPersonas
     JOIN Roles r              ON r.idRoles = pr.Roles_idRoles
     LEFT JOIN Sedes s         ON s.idSedes = p.Sedes_idSedes
     WHERE u.idUsuarios = ?
     LIMIT 1`,
    [idUsuarios]
  );
  if (!rows.length) return null;
  const u = rows[0];
  return {
    idUsuarios: u.idUsuarios,
    email: u.email,
    nickname: u.nickname,
    userActivo: Number(u.UserActivo) === 1,
    idPersonas: u.idPersonas,
    idSedes: u.Sedes_idSedes,
    sede: u.SedeNombre || null,
    municipio: u.Municipio || null,
    rolId: u.Roles_idRoles,
    rol: u.Tipo_usuario,
  };
}

/** Sedes permitidas por rol (Antigua = 3 sedes) */
async function computeSedesPermitidas(perfil) {
  if (!perfil) return [];
  if (["Administrador", "Secretaria"].includes(perfil.rol)) {
    const [all] = await pool.query(`SELECT idSedes, Nombre, Municipio FROM Sedes ORDER BY Nombre`);
    return all;
  }
  if (perfil.rol === "Sensei Antigua Guatemala") {
    const [ant] = await pool.query(
      `SELECT idSedes, Nombre, Municipio FROM Sedes WHERE Municipio='Antigua Guatemala' ORDER BY Nombre`
    );
    return ant;
  }
  if (perfil.idSedes) {
    const [one] = await pool.query(`SELECT idSedes, Nombre, Municipio FROM Sedes WHERE idSedes=?`, [perfil.idSedes]);
    return one;
  }
  return [];
}

export async function requireAuth(req, res, next) {
  try {
    const auth = req.headers.authorization || "";
    const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;
    if (!token) return res.status(401).json({ ok:false, msg:"No autorizado" });

    let payload;
    try { payload = jwt.verify(token, JWT_SECRET); }
    catch { return res.status(401).json({ ok:false, msg:"Token inválido" }); }

    if (!payload?.idUsuarios) return res.status(401).json({ ok:false, msg:"Token sin idUsuarios" });

    const perfil = await fetchUserProfile(payload.idUsuarios);
    if (!perfil || !perfil.userActivo) return res.status(401).json({ ok:false, msg:"Usuario inactivo/no encontrado" });

    const sedesPermitidas = await computeSedesPermitidas(perfil);
    req.user = { ...perfil, sedesPermitidas };
    next();
  } catch (e) {
    console.error("[requireAuth]", e);
    res.status(500).json({ ok:false, msg:"Error de autenticación" });
  }
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ ok:false, msg:"No autorizado" });
    if (!roles.includes(req.user.rol)) return res.status(403).json({ ok:false, msg:"Prohibido" });
    next();
  };
}

export const allowAdminOrSec = requireRole("Administrador", "Secretaria");
